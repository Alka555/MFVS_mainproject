# integrityverficationformediafile
smart integrity verification system for media files using blockchain is a django based web application.The system will checks the integrity of media files using the blockchain technology.The system generate a hash code for mediafiles. Solidity is used to develop the smart contract and is deployed in ganache. 
